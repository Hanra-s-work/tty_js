/*
** EPITECH PROJECT, 2023
** 102architect
** File description:
** functions for 102architect
*/

#include <stdio.h>
#include <my.h>
#include <my_102architect.h>
#include <my_macro_isnum.h>

int help(void)
{
    printf("%s%s%s%s%s%s%s%s", "USAGE\n    ./102architect x y transfo1 arg11 ",
        "[arg12] [transfo2 arg21 [arg22]] ...\n\nDESCRIPTION\n    x   absciss",
        "a of the original point\n    y   ordinate of the original point\n\n ",
        "   transfo arg1 [arg2]\n    -t i j  translation along vector (i, j)",
        "\n    -z m n  scaling by factors m (x-axis) and n (y-axis)\n    -r d",
        "    rotation centered in O by a d degree angle\n    -s d    reflecti",
        "on over the axis passing through O with an inclination\n            ",
        "angle of d degrees\n");
    return 0;
}

void display_actions(char flag, char **av, int compteur)
{
    if (flag == 't')
        printf("Translation along vector (%d, %d)\n",
            my_getnbr(av[compteur + 1]), my_getnbr(av[compteur + 2]));
    if (flag == 'z')
        printf("Scaling by factors %d and %d\n",
            my_getnbr(av[compteur + 1]), my_getnbr(av[compteur + 2]));
    if (flag == 'r')
        printf("Rotation by a %d degree angle\n",
            my_getnbr(av[compteur + 1]));
    if (flag == 's')
        printf("Reflection over an axis with an inclination angle of %d%s",
            my_getnbr(av[compteur + 1]), " degrees\n");
}

void display_result(double *tab, int x, int y)
{
    double a = tab[0] * x + tab[1] * y + tab[2];
    double b = tab[3] * x + tab[4] * y + tab[5];

    for (int i = 0; i < 9; i += 3)
        printf("%.2f %.2f %.2f\n", tab[i], tab[i + 1], tab[i + 2]);
    printf("(%d.00, %d.00) => (%.2f, %.2f)\n", x, y, a, b);
}

static int test3(char *av)
{
    for (int i = 0; i < my_strlen(av); i += 1)
        if (!ISNUM(av[i]) && !(av[i] == '-' && i == 0))
            return 1;
    return 0;
}

static int test2(int ac, char **av, int y, geo_t *fun)
{
    int temp = 0;

    for (int i = 1; i < my_strlen(av[y]); i += 1)
        if (((av[y][i] != 't' && av[y][i] != 'z' && av[y][i] != 'r'
            && av[y][i] != 's') && i == 1) || (av[y][i] != '\0' && i > 1))
            return 1;
    for (temp = 0; av[y][1] != fun[temp].type; temp += 1);
    temp = fun[temp].args;
    for (int j = 0; j <= temp; j += 1)
        if (j + y > ac)
            return 1;
    return 0;
}

int test(int ac, char **av, geo_t *fun)
{
    int temp = 0;

    for (int i = 1; i < ac; i += 1) {
        if (av[i][0] == '-' && !ISNUM(av[i][1]))
            temp = test2(ac, av, i, fun);
        if (temp == 1)
            return 1;
        if (av[i][0] != '-')
            temp = test3(av[i]);
        if (temp == 1)
            return 1;
    }
    return 0;
}
