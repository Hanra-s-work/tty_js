/*
** EPITECH PROJECT, 2023
** 102architect
** File description:
** Main function for 102architect
*/

#include <my_102architect.h>
#include <my.h>

int main(int ac, char **av)
{
    double tab[] = {0, 0, 0, 0, 0, 0, 0, 0, 0};
    geo_t fun[4];

    create_functions(fun);
    if (test(ac, av, fun) == 1)
        return 84;
    if (ac == 2 && my_strlen(av[1]) == 2 && av[1][0] == '-'
        && av[1][1] == 'h')
        return help();
    if (ac >= 5) {
        for (int i = 3; i < ac; i += 1) {
            display_actions(av[i][1], av, i);
            compute_trasfo(&i, av, tab, fun);
        }
        display_result(tab, my_getnbr(av[1]), my_getnbr(av[2]));
        return 0;
    }
    return 84;
}
