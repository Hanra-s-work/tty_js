/*
** EPITECH PROJECT, 2023
** 102architect
** File description:
** Functions for 102architect
*/

#include <math.h>
#include <my_102architect.h>

void reflect(double *tab, int d)
{
    double a = 2 * d / (180 / M_PI);
    double matrice[] = {cos(a), sin(a), 0, sin(a), -cos(a), 0, 0, 0, 1};

    fill_tab(tab, matrice);
}

void rotate(double *tab, int d)
{
    double a = d / (180 / M_PI);
    double matrice[] = {cos(a), -sin(a), 0, sin(a), cos(a), 0, 0, 0, 1};

    fill_tab(tab, matrice);
}

void scale(double *tab, int m, int n)
{
    double matrice[] = {m, 0, 0, 0, n, 0, 0, 0, 1};

    fill_tab(tab, matrice);
}

void translate(double *tab, int i, int j)
{
    double matrice[] = {1, 0, i, 0, 1, j, 0, 0, 1};

    fill_tab(tab, matrice);
}
