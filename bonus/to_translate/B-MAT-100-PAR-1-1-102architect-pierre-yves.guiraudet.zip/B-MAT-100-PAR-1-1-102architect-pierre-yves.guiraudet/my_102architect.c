/*
** EPITECH PROJECT, 2023
** 102architect
** File description:
** Compute every geometry transformation
*/

#include <stdio.h>
#include <my.h>
#include <my_102architect.h>

void create_functions(geo_t *fun)
{
    geo_t nw_fun[4] = {{'t', 2, &translate, NULL}, {'z', 2, &scale, NULL},
        {'r', 1, NULL, &rotate}, {'s', 1, NULL, &reflect}};

    for (int i = 0; i < 4; i += 1)
        fun[i] = nw_fun[i];
}

int is_empty(double *tab)
{
    for (int i = 0; i < 9; i += 1)
        if (tab[i] != 0)
            return 0;
    return 1;
}

void compute(double *tab, double *matrice, double *mat2)
{
    for (int i = 0; i < 9; i += 1) {
        tab[i] = 0;
        for (int j = 0; j < 3; j += 1)
            tab[i] += matrice[i / 3 * 3 + j] * mat2[j * 3 + i - i / 3 * 3];
    }
}

void fill_tab(double *tab, double *matrice)
{
    double mat2[] = {tab[0], tab[1], tab[2], tab[3], tab[4], tab[5], tab[6],
        tab[7], tab[8]};

    if (is_empty(tab))
        for (int i = 0; i < 9; i += 1)
            tab[i] = matrice[i];
    else
        compute(tab, matrice, mat2);
}

void compute_trasfo(int *i, char **av, double *tab, geo_t *fun)
{
    for (int j = 0; j < 4; j += 1) {
        if (av[*i][1] == fun[j].type && fun[j].args == 1)
            (fun[j].fct2)(tab, my_getnbr(av[*i + 1]));
        if (av[*i][1] == fun[j].type && fun[j].args == 2)
            (fun[j].fct)(tab, my_getnbr(av[*i + 1]), my_getnbr(av[*i + 2]));
        if (av[*i][1] == fun[j].type)
            *i += fun[j].args;
    }
}
