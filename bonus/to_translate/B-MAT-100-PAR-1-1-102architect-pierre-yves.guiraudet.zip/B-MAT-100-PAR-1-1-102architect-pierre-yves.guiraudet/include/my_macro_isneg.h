/*
** EPITECH PROJECT, 2023
** my_macro_isneg
** File description:
** Replaces an argument with a sign
*/

#ifndef MY_MACRO_ISNEG_H
    #define MY_MACRO_ISNEG_H
    #define ISNEG(value)        ((value < 0) ? (-1) : (1))
#endif
