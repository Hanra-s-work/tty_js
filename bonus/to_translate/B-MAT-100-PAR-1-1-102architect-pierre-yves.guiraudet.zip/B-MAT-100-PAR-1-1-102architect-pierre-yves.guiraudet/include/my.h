/*
** EPITECH PROJECT, 2023
** my
** File description:
** my library prototypes
*/

#ifndef MY_H
    #define MY_H

int my_strlen(char const *str);
int my_getnbr(char const *str);
int my_getnbr_bis(int start, int end, char const *str);

#endif
