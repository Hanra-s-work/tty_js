/*
** EPITECH PROJECT, 2023
** my_macro_abs
** File description:
** Replaces an argument with an absolute value
*/

#ifndef MY_MACRO_ABS_H
    #define MY_MACRO_ABS_H
    #define ABS(value)        ((value < 0) ? (value * -1) : (value))
#endif
