/*
** EPITECH PROJECT, 2023
** my_macro_isnum
** File description:
** Replaces an argument with a bool
*/

#ifndef MY_MACRO_ISNUM_H
    #define MY_MACRO_ISNUM_H
    #define ISNUM(value)        ((value > 47 && value < 58) ? (1) : (0))
#endif
