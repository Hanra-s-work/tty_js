/*
** EPITECH PROJECT, 2023
** 102architect
** File description:
** Srtuct for 102architect
*/

#ifndef MY_102ARCHITECT_H
    #define MY_102ARCHITECT_H

typedef struct geo {
    char type;
    int args;
    void (*fct) (double *tab, int x, int y);
    void (*fct2) (double *tab, int x);
} geo_t;

void create_functions(geo_t *fun);
void fill_tab(double *tab, double *matrice);
void compute_trasfo(int *i, char **av, double *tab, geo_t *fun);
int help(void);
void display_actions(char flag, char **av, int compteur);
void display_result(double *tab, int x, int y);
int test(int ac, char **av, geo_t *fun);

void reflect(double *tab, int d);
void rotate(double *tab, int d);
void scale(double *tab, int m, int n);
void translate(double *tab, int i, int j);

#endif
