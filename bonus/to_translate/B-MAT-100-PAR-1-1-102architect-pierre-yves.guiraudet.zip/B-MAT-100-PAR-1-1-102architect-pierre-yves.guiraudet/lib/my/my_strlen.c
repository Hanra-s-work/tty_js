/*
** EPITECH PROJECT, 2023
** my_strlen
** File description:
** Return the number of caracters of a string
*/

#include <unistd.h>

int my_strlen(char const *str)
{
    int i = 0;

    while (str[i] != 0) {
            i += 1;
        }
    return (i);
}
