/*
** EPITECH PROJECT, 2023
** functions.c
** File description:
** struct type and prototypes of multiples functions
*/

#ifndef TYPE_H
    #define TYPE_H

typedef struct type{
    char flag;
    void (*point) (va_list, const char *, int *, char *);
} type_t;

void find_nb(va_list ap, const char *format, int *ai, char *flags);

char *reset_flags(char *flags);
int rev_puis(int puis);
int find_width(const char *format, int *ai);
int find_precision(char const *format, int *ai);

int place_spaces(char *flags, int width, int lenght, int place);
int find_htag(char *flags, int *ai, char *nb, char c);
int space(char *flags, int nb);

void type_i(va_list ap, const char *format, int *ai, char *flags);
void type_f(double *d, const char *format, int *ai, char *flags);
void type_f_recup(va_list ap, const char *format, int *ai, char *flags);
void type_f_maj_recup(va_list ap, const char *format, int *ai, char *flags);
void type_u(va_list ap, const char *format, int *ai, char *flags);
void type_o(va_list ap, const char *format, int *ai, char *flags);
void type_x(va_list ap, const char *format, int *ai, char *flags);
void type_x_maj(va_list ap, const char *format, int *ai, char *flags);
void type_n(va_list ap, const char *format, int *ai, char *flags);
void type_s(va_list ap, const char *format, int *ai, char *flags);
void type_c(va_list ap, const char *format, int *ai, char *flags);
void type_p(va_list ap, const char *format, int *ai, char *flags);
void type_pourcent(va_list ap, const char *format, int *ai, char *flags);
void type_e(double *d, const char *format, int *ai, char *flags);
void type_e_recup(va_list ap, const char *format, int *ai, char *flags);
void type_e_maj_recup(va_list ap, const char *format, int *ai, char *flags);
void type_g(double *d, const char *format, int *ai, char *flags);
void type_g_recup(va_list ap, const char *format, int *ai, char *flags);
void type_g_maj_recup(va_list ap, const char *format, int *ai, char *flags);

#endif
