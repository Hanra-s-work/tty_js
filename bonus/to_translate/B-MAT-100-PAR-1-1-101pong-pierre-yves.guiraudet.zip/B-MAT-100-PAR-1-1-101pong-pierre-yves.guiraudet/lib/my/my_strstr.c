/*
** EPITECH PROJECT, 2023
** my_strstr
** File description:
** Find to_find first occurence in str
*/

#include <stddef.h>

int my_strstr2(int y, char *str, char const *to_find, int i)
{
    if (str[i] == to_find[y]) {
        y += 1;
    } else {
        y = 0;
    }
    return (y);
}

char *my_strstr(char *str, char const *to_find, int n)
{
    int compteur;
    int i = 0;
    char *str2;
    char a = NULL;

    str2 = &a;
    for (compteur = 0; to_find[compteur] != '\0'; compteur += 1) {
    }
    for (int y = 0; str[i] != '\0' && y < n; i += 1) {
        y = my_strstr2(y, str, to_find, i);
        if (y == compteur && y > 1) {
            return (&str[i - compteur + 1]);
        }
        if (y == compteur) {
            return (&str[i - compteur]);
        }
    }
    return (str2);
}
