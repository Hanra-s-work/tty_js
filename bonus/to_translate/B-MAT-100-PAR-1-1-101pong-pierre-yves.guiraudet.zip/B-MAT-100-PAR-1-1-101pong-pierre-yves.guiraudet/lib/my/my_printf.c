/*
** EPITECH PROJECT, 2023
** my_printf.c
** File description:
** Display anything
*/

#include <stdarg.h>
#include "../../include/my.h"
#include "../../include/functions.h"
#include "../../include/my_macro_isneg.h"
#include "../../include/my_macro_isnum.h"

void make_flags(type_t *a, int nb)
{
    type_t b[] = {{'i', &type_i}, {'d', &type_i}, {'f', &type_f_recup},
        {'F', &type_f_maj_recup}, {'s', &type_s}, {'.', &find_nb},
        {'o', &type_o}, {'x', &type_x}, {'X', &type_x_maj},
        {'n', &type_n}, {'p', &type_p}, {'c', &type_c},
        {'u', &type_u}, {'e', &type_e_recup}, {'E', &type_e_maj_recup},
        {'g', &type_g_recup}, {'G', &type_g_maj_recup}};

    for (int i = 0; i < nb; i += 1)
        a[i] = b[i];
}

int *find_conversion(va_list ap, const char *format, int *ai, char *flags)
{
    int nb = 18;
    type_t tab[nb];

    make_flags(tab, nb);
    for (int j = 0; j < nb; j += 1) {
        if (tab[j].flag == format[ai[1] - (1 + my_strlen(flags))]) {
            (tab[j].point)(ap, &format[ai[2]], ai, flags);
            return (ai);
        }
    }
    return (ai);
}

void find_nb(va_list ap, const char *format, int *ai, char *flags)
{
    if ((format[ai[1] - (1 + my_strlen(flags))] == '.'
        || ISNUM(format[ai[1]- (1 + my_strlen(flags))]))
        && ai[1] == my_strlen(flags) + 1)
        ai[2] -= 1;
    if (format[ai[1] - (1 + my_strlen(flags))] == '.')
        ai[1] += 1;
    for (; ISNUM(format[ai[1] - (1 + my_strlen(flags))]); ai[1] += 1);
    find_conversion(ap, format, ai, flags);
}

void find_flag(va_list ap, const char *format, int *ai, char *flags)
{
    if (format[ai[1] - 1] == '#' || format[ai[1] - 1] == '-'
        || format[ai[1] - 1] == '+' || format[ai[1] - 1] == '0'
        || format[ai[1] - 1] == ' ') {
        ai[1] += 1;
        my_strncat(flags, format, 1);
        find_flag(ap, &format[1], ai, flags);
    } else {
        find_nb(ap, format, ai, flags);
    }
}

int my_printf(const char *format, ...)
{
    va_list ap;
    int ai[] = {0, 1, 1};
    char flags[5];

    va_start(ap, format);
    for (int i = 0; i < my_strlen(format); i += 1) {
        if (format[i] == '%') {
            find_flag(ap, &format[i + 1], ai, reset_flags(flags));
            i += ai[1];
        } else {
            my_putchar(format[i]);
            ai[0] += 1;
        }
        ai[1] = 1;
        ai[2] = 1;
    }
    va_end(ap);
    return (ai[0]);
}
