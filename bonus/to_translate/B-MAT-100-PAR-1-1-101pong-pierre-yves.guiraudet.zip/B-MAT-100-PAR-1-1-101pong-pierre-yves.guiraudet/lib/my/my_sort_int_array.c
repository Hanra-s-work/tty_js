/*
** EPITECH PROJECT, 2023
** my_sort_int_array
** File description:
** Sort an integer array in ascending order
*/

#include <unistd.h>

void my_sort_int_array(int *array, int size)
{
    int a = 0;
}
