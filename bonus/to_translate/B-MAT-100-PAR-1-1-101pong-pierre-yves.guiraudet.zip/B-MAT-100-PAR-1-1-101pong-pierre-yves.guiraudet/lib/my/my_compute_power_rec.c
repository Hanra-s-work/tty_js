/*
** EPITECH PROJECT, 2023
** my_compute_power_rec
** File description:
** A recursive function that return the first argument raised to the power p
*/

int my_compute_power_rec(int nb, int p)
{
    if (p < 0) {
        return (0);
    }
    if (p == 0) {
        return (1);
    }
    return (my_compute_power_rec(nb, p - 1) * nb);
}
