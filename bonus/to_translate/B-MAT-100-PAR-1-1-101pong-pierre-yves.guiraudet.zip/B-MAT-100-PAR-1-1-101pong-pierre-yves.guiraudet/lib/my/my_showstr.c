/*
** EPITECH PROJECT, 2023
** my_showstr
** File description:
** Display an str if its printable
*/

int my_showstr(char const *str)
{
    return (0);
}
