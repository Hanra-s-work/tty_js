/*
** EPITECH PROJECT, 2023
** my_find_prime_sup
** File description:
** Returns the prime number that is greater or equal to the parameter
*/

int my_find_prime_sup(int nb)
{
    int i;

    for (int nbr = nb; nbr < 2147483647; nbr += 1) {
        for (i = 2; (nbr % i) > 0 && i <= nbr; i += 1) {
        }
        if (i == nbr) {
            return (nbr);
        }
    }
    return (0);
}
