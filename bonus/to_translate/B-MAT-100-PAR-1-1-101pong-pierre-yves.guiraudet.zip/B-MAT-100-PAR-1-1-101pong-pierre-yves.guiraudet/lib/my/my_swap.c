/*
** EPITECH PROJECT, 2023
** my_swap
** File description:
** Swap two intergers with there adress
*/

#include <unistd.h>

void my_swap(int *a, int *b)
{
    int c = *b;
    int d = *a;

    *a = c;
    *b = d;
}
