/*
** EPITECH PROJECT, 2023
** my_putnbr_base
** File description:
** Converts and displays a decimal number into a number in a given base
*/

#include <unistd.h>

char *my_putnbr_base(unsigned int nbr, char const *base)
{
    unsigned int i;
    unsigned int puis;
    unsigned int a = 0;
    char *nb;

    for (i = 0; base[i] != '\0'; i += 1);
    for (puis = 1; (i * puis) < nbr; puis *= i) {
        a += 1;
    }
    nb = malloc(sizeof(char) * a);
    a = 0;
    for (; puis >= 1; puis /= i) {
        nb[a] = base[nbr / puis];
        nbr %= puis;
        a += 1;
    }
    return (nb);
}
