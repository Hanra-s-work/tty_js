/*
** EPITECH PROJECT, 2023
** my_strdup
** File description:
** Allocates memory and copies the string given in it
*/

#include <stdlib.h>

char *my_strdup(char const *src)
{
    char *str;
    int i;

    str = malloc(my_strlen(src) + 1);
    for (i = 0; src[i] != '\0'; i += 1) {
        str[i] = src[i];
    }
    str[i] = '\0';
    return (str);
}
