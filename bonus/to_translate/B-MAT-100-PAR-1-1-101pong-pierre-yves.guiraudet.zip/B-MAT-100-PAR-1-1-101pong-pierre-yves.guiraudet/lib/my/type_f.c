/*
** EPITECH PROJECT, 2023
** type_f.c
** File description:
** Functions %f and %F.
*/

#include <stdarg.h>
#include <math.h>
#include "../../include/my.h"
#include "../../include/functions.h"
#include "../../include/my_macro_abs.h"

void type_f_suite(int *ai, int *temp, int *puis, char *flags)
{
    ai[0] += place_spaces(flags, temp[1],
        (rev_puis(puis[2]) + (temp[3] != 0) + (temp[1] < 0)), 0);
    temp[0] = ABS(temp[3]);
    for (int i = -1; (temp[2] > i && temp[6] == 1)
        || (puis[0] > 0 && temp[6] == 0); i += 1) {
        if (puis[0] * 10 >= puis[1] && puis[0] * 10 == puis[2] && temp[2] != 0)
            temp[4] = 2;
        if (temp[0] / puis[0] == 0 && temp[0] % puis[0] == 0 && temp[6])
            temp[4] = 0;
        if (temp[4] > 1)
            my_putchar('.');
        if (temp[4] > 0)
            my_put_nbr(temp[0] / puis[0]);
        if (temp[4] > 1)
            temp[4] = 1;
        temp[0] %= puis[0];
        puis[0] /= 10;
    }
    ai[0] += place_spaces(flags, temp[1],
        (rev_puis(puis[2]) + (temp[3] != 0) + (temp[1] < 0)), 1);
}

void type_f(double *tab, const char *format, int *ai, char *flags)
{
    int puis[] = {1, 1, 1};
    int temp[] = {tab[0], find_width(format, ai), find_precision(format, ai),
        0, 1, (int) tab[1], (int) tab[2]};

    if (temp[2] == -1)
        temp[2] = 6;
    for (double d_bis = ABS(tab[0]); temp[6] == 1 && d_bis < 1; d_bis *= 10)
        temp[2] += 1;
    for (double d_bis = ABS(tab[0]); d_bis >= 10; d_bis /= 10)
        puis[0] *= 10;
    for (int i = 0; i < temp[2] - ((rev_puis(puis[0]) - 1) * temp[6]); i += 1){
        puis[0] *= 10;
        tab[0] *= 10;
    }
    puis[1] *= puis[0] / ((ABS(temp[0]) < 1) * 9 + 1);
    puis[2] *= puis[0];
    my_putchar((tab[0] < 0) * '-');
    temp[3] = tab[0];
    ai[0] += (temp[2] != 0) + (temp[0] < 0) + rev_puis(puis[0]);
    type_f_suite(ai, temp, puis, flags);
}

int typef_inf_nan(double d, int *ai, int maj)
{
    char *arr[] = {"NAN", "nan", "INF", "inf"};

    if (d == 0.0 / 0.0) {
        my_putstr(arr[maj]);
        ai[0] += 3;
        return (0);
    }
    if (d == INFINITY) {
        if (d < 0) {
            my_putchar('-');
            ai[0] += 1;
        }
        my_putstr(arr[maj + 2]);
        ai[0] += 3;
        return (0);
    }
    return (1);
}

void type_f_recup(va_list ap, const char *format, int *ai, char *flags)
{
    double tab[] = {va_arg(ap, double), 1, 0};

    if (typef_inf_nan(tab[0], ai, 1))
        ai[0] += space(flags, (int) tab[0]);
        type_f(tab, format, ai, flags);
}

void type_f_maj_recup(va_list ap, const char *format, int *ai, char *flags)
{
    double tab[] = {va_arg(ap, double), 0, 0};

    if (typef_inf_nan(tab[0], ai, 0))
        ai[0] += space(flags, (int) tab[0]);
        type_f(tab, format, ai, flags);
}
