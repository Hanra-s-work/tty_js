/*
** EPITECH PROJECT, 2023
** my_put_nbr2
** File description:
** Display the number given as parameter
*/

#include <unistd.h>

int my_put_nbr3(int nbr, int nb2, int compteur)
{
    if (nbr < 0) {
        my_putchar((nbr * -1) + 48);
    } else {
        my_putchar(nbr + 48);
    }
    nbr = nb2 - nbr * compteur;
    if (nbr == 0 && compteur != 1) {
        compteur /= 10;
        while (compteur != 1) {
            my_putchar(48);
            compteur /= 10;
        }
    }
    if (compteur != 1) {
        while ((compteur / nbr) < -10 || (compteur / nbr) > 10) {
            my_putchar(48);
            compteur /= 10;
        }
    }
    return (nbr);
}

int my_put_nbr2(int nbr, int nb2, int compteur)
{
    while ((nbr > 10) || (nbr < -10)) {
        nbr = nbr / 10;
        compteur *= 10;
        if ((nbr < 10) && (nbr > -10)) {
            nbr = my_put_nbr3(nbr, nb2, compteur);
            nb2 = nbr;
            compteur = 1;
        }
    }
    return (nbr);
}

int my_put_nbr1(int nb)
{
    int nb2 = nb;
    int compteur = 1;

    if (nb < 0) {
        my_putchar(45);
    }
    nb = my_put_nbr2(nb, nb2, compteur);
    if (nb < 0) {
        my_putchar((nb * -1) + 48);
    } else {
        my_putchar(nb + 48);
    }
    return (0);
}
