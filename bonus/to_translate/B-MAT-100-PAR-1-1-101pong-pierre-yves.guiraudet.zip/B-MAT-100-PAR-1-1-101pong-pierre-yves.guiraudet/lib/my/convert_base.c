/*
** EPITECH PROJECT, 2023
** convert_base
** File description:
** Returns the result from the nbr string conversion
*/

#include <stdlib.h>
#include "../../include/my.h"

char *convert_base4(unsigned long long int nbr, char const *base)
{
    unsigned long long int tab[2];
    char *str;
    unsigned long long int mem = 0;
    unsigned long long int compteur = 0;

    for (tab[0] = 0; base[tab[0]] != '\0'; tab[0] += 1) {
    }
    for (tab[1] = 1; (tab[0] * tab[1]) < nbr; tab[1] *= tab[0]) {
        mem += 1;
    }
    str = malloc(mem + 2);
    for (; tab[1] >= 1; tab[1] /= tab[0]) {
        str[compteur] = base[nbr / tab[1]];
        nbr %= tab[1];
        compteur += 1;
    }
    str[compteur] = '\n';
    return (str);
}

int convert_base3(int x, int i)
{
    int puis = 1;

    for (int z = 0; z < x - 1 ; puis *= i) {
        z += 1;
    }
    return (puis);
}

int convert_base2(char const *base)
{
    int i;

    for (i = 0; base[i] != '\0'; i += 1) {
    }
    return (i);
}

char *convert_base(char const *nbr, char const *base_from, char const *base_to)
{
    unsigned long long int i;
    unsigned long long int puis;
    unsigned long long int nb = 0;
    unsigned long long int x;
    unsigned long long int j;

    for (x = 0; nbr[x] != '\0'; x += 1);
    for (i = 0; base_from[i] != '\0'; i += 1);
    for (unsigned long long int z = 0; z < x - 1 ; puis *= i) {
        z += 1;
    }
    for (unsigned long long int y = 0; puis >= 1; puis /= i) {
        for (j = 0; base_from[j] != nbr[y]; j += 1) {
        }
        nb += j * puis;
        y += 1;
    }
    return (convert_base4(nb, base_to));
}
