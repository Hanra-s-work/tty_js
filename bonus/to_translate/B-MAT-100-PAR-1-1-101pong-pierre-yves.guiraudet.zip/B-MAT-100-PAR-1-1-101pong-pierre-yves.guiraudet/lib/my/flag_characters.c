/*
** EPITECH PROJECT, 2023
** flags_charcters.c
** File description:
** Functions for the flag %# %0 %- %[SPACE] %+
*/

#include "../../include/my.h"

int find_htag_suite(char *flags, int *ai, char *nb, char c)
{
    switch (c) {
    case 'o':
        my_putchar('0' * (nb[0] != '0'));
        ai[0] += nb[0] != '0';
        return (0);
    case 'g':
        return (0);
    case 'a':
    case 'e':
    case 'f':
        return (0);
    default:
        return (1);
    }
}

int find_htag(char *flags, int *ai, char *nb, char c)
{
    int cond = 0;

    for (int temp = 0; flags[temp] != '\0'; temp += 1)
        cond += (flags[temp] == '#');
    if (cond) {
        switch (c) {
        case 'x':
            my_putstr("0x");
            ai[0] += 2;
            return (0);
        case 'X':
            my_putstr("0X");
            ai[0] += 2;
            return (0);
        default:
            return (find_htag_suite(flags, ai, nb, c));
        }
    }
    return (1);
}

int place_spaces(char *flags, int width, int lenght, int place)
{
    int cond = 0;
    int i = 0;

    for (int temp = 0; flags[temp] != '\0'; temp += 1) {
        if (flags[temp] == '-')
            cond = 1;
        if (flags[temp] == '0' && cond == 0)
            cond = 2;
    }
    for (; cond == place && width > lenght + i; i += 1) {
        my_putchar(' ');
    }
    for (; cond == 2 && place == 0 && width > lenght + i; i += 1) {
        my_putchar('0');
    }
    return (i);
}

int space(char *flags, int nb)
{
    int cond = 0;

    for (int temp = 0; flags[temp] != '\0'; temp += 1) {
        if (flags[temp] == '+')
            cond = 1;
        if (flags[temp] == ' ' && cond == 0)
            cond = 2;
    }
    if (cond == 1 && nb >= 0) {
        my_putchar('+');
        return (1);
    }
    if (cond == 2 && nb >= 0) {
        my_putchar(' ');
        return (1);
    }
    return (0);
}
