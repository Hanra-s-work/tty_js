/*
** EPITECH PROJECT, 2023
** find_width_precision
** File description:
** Function returning width and precision
*/

#include <stddef.h>
#include "../../include/my.h"
#include "../../include/my_macro_isnum.h"

char *reset_flags(char *flags)
{
    for (int temp = 0; temp < my_strlen(flags); temp += 1)
        flags[temp] = '\0';
    return (flags);
}

int rev_puis(int puis)
{
    if (puis == 1)
        return (1);
    return (1 + rev_puis(puis / 10));
}

int find_width(const char *format, int *ai)
{
    if (!ISNUM(format[0]))
        return (0);
    return (my_getnbr(my_strdup(format)));
}

int find_precision(char const *format, int *ai)
{
    for (int i = 0; i < ai[1]; i += 1) {
        if (format[i] == '.')
            return (my_getnbr(&format[i + 1]));
    }
    return (-1);
}
