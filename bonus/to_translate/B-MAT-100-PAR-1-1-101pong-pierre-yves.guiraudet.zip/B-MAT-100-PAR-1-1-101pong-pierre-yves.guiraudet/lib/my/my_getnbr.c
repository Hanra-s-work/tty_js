/*
** EPITECH PROJECT, 2023
** my_getnbr
** File description:
** Rreturn the number given as a string
*/

#include <unistd.h>

int my_getnbr_bis(int start, int end, char const *str)
{
    int nb = 0;
    int coef = 1;

    for (int i = start; i < end; i += 1) {
        for (int end1 = end; (end1 - i) != 1; end1 -= 1) {
            coef *= 10;
        }
        if (coef > 100000000 && ((int) str[i] - 48) < 4) {
            return (0);
        }
        nb += (((int) str[i]) - 48) * coef;
        coef = 1;
    }
    if ((int) str[start - 1] == 45) {
        nb *= -1;
    }
    return (nb);
}

int my_getnbr(char const *str)
{
    int i = 0;
    int start;
    int end;
    int nb;

    for (; str[i] != '\0' && (str[i] == '-' || str[i] == '+'); i += 1);
    start = i;
    if ((int) str[i] < 48 || (int) str[i] > 57)
        return (0);
    for (; str[i] != '\0' && ((int) str[i]) > 47 && ((int) str[i]) < 58;
        i += 1);
    end = i;
    return (my_getnbr_bis(start, end, str));
}
