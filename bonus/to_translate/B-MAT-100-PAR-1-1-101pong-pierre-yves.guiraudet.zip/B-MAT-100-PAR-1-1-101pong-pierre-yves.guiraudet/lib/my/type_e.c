/*
** EPITECH PROJECT, 2023
** type_expoenet
** File description:
** functions for %e %E
*/

#include <stdarg.h>
#include "../../include/my.h"
#include "../../include/functions.h"
#include "../../include/my_macro_abs.h"

void type_e_exp(int *ai, int *temp, int *puis, char *flags)
{
    int i = 0;

    my_putchar('E' + 32 * temp[5]);
    if (puis[0] == 0 && puis[1] > 1) {
        i = rev_puis(puis[1]) - 1;
        my_putchar('-');
    } else if (puis[1] == 1) {
        my_putchar('+');
    } else {
        i = rev_puis(puis[1] / puis[0]) - 1;
        my_putchar('+');
    }
    if (i < 10)
        my_put_nbr(0);
    my_put_nbr(i);
    ai[0] += place_spaces(flags, temp[1],
        ((temp[2] != 0) + (temp[3] < 0) + temp[2] + 5), 1);
}

void type_e_suite(int *ai, int *temp, int *puis, char *flags)
{
    ai[0] += place_spaces(flags, temp[1],
        ((temp[2] != 0) + (temp[0] < 0) + temp[2] + 5), 0);
    my_putchar((temp[0] < 0) * '-');
    temp[0] = ABS(temp[0]);
    for (int i = -1; temp[2] > i; i += 1) {
        if (i == 0 && temp[2] != 0)
            temp[4] = 2;
        if (temp[0] / puis[0] == 0 && temp[0] % puis[0] == 0 && temp[6])
            temp[4] = 0;
        if (temp[4] > 1)
            my_putchar('.');
        if (temp[4] > 0)
            my_put_nbr(temp[0] / puis[0]);
        if (temp[4] > 1)
            temp[4] = 1;
        temp[0] %= puis[0];
        puis[0] /= 10;
    }
    type_e_exp(ai, temp, puis, flags);
}

void type_e(double *tab, const char *format, int *ai, char *flags)
{
    int puis[] = {1, 1, 0};
    int temp[] = {0, find_width(format, ai), find_precision(format, ai),
        0, 1, (int) tab[1], (int) tab[2]};

    if (temp[2] == -1)
        temp[2] = 6;
    for (double d_bis = tab[0]; ABS((int) d_bis) > 10; d_bis /= 10)
        puis[0] *= 10;
    puis[1] *= puis[0];
    for (; ABS((int) tab[0]) < 1; tab[0] *= 10)
        puis[1] *= 10;
    puis[2] += puis[0];
    for (int i = 0; i < temp[2] - (rev_puis(puis[2]) - 1); i += 1) {
        puis[0] *= 10;
        tab[0] *= 10;
    }
    temp[0] = tab[0];
    temp[3] += temp[0];
    ai[0] += (temp[2] != 0) + (temp[0] < 0) + temp[2] + 5;
    type_e_suite(ai, temp, puis, flags);
}

void type_e_recup(va_list ap, const char *format, int *ai, char *flags)
{
    double tab[] = {va_arg(ap, double), 1, 0};

    ai[0] += space(flags, (int) tab[0]);
    type_e(tab, format, ai, flags);
}

void type_e_maj_recup(va_list ap, const char *format, int *ai, char *flags)
{
    double tab[] = {va_arg(ap, double), 0, 0};

    ai[0] += space(flags, (int) tab[0]);
    type_e(tab, format, ai, flags);
}
