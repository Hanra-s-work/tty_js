/*
** EPITECH PROJECT, 2023
** type_g_i_a.c
** File description:
** Functions with %g, %G, %i, %a, %A.
*/

#include <stdarg.h>
#include <stdlib.h>
#include "../../include/my.h"
#include "../../include/functions.h"
#include "../../include/my_macro_isnum.h"
#include "../../include/my_macro_abs.h"

void type_i(va_list ap, const char *format, int *ai, char *flags)
{
    int a = va_arg(ap, int);
    int prec = 0;
    int i = 1;
    int width = find_width(my_strdup(format), ai);

    if (a != 0 || find_precision(format, ai) != 0) {
        for (int temp = a; temp >= 10; i += 1)
            temp /= 10;
        for (int temp = find_precision(format, ai); temp > i; temp -= 1)
            prec += 1;
        ai[0] += space(flags, a);
        ai[0] += place_spaces(flags, width, i + prec, 0);
        for (int temp = 0; temp < prec; temp += 1)
            my_putchar('0');
        my_put_nbr(a);
        ai[0] += i + prec;
        ai[0] += place_spaces(flags, width, i + prec, 1);
    }
}

void type_g_suite(double *d, int *temp, int *ai, char **format_tab)
{
    int puis[] = {0, 0};
    char ch[1];

    ch[0] = '.';
    my_strncat(format_tab[0], ch, 1);
    if (temp[0] > 9)
        ch[0] = '0' + temp[0] / 10;
    my_strncat(format_tab[0], ch, (ch[0] == '0'));
    ch[0] = '0' + temp[0] % 10;
    my_strncat(format_tab[0], ch, 1);
    for (double d_bis = d[0]; ABS(d_bis) >= 10; d_bis /= 10)
        puis[0] += 1;
    for (double d_bis = d[0]; ABS(d_bis) < 1; d_bis *= 10)
        puis[1] += 1;
    if (puis[0] >= temp[0] + 1 || puis[1] > 4)
        type_e(d, format_tab[0], ai, format_tab[1]);
    else
        type_f(d, format_tab[0], ai, format_tab[1]);
}

void type_g(double *d, const char *format, int *ai, char *flags)
{
    int temp[] = {find_precision(format, ai), find_width(format, ai)};
    char *format_tab[2];
    int i = 0;

    format_tab[1] = malloc(sizeof(char) * my_strlen(flags));
    my_strcat(format_tab[1], flags);
    for (; ISNUM(format[i]); i += 1);
    if (temp[0] > 0)
        temp[0] -= 1;
    if (temp[0] == -1)
        temp[0] = 5;
    format_tab[0] = malloc(sizeof(char) * (i + 2 + (temp[0] > 9)));
    if (i > 0)
        my_strncat(format_tab[0], format, i);
    type_g_suite(d, temp, ai, format_tab);
}

void type_g_recup(va_list ap, const char *format, int *ai, char *flags)
{
    double tab[] = {va_arg(ap, double), 1,
        find_htag(flags, ai, "", 'g')};

    ai[0] += space(flags, (int) tab[0]);
    type_g(tab, format, ai, flags);
}

void type_g_maj_recup(va_list ap, const char *format, int *ai, char *flags)
{
    double tab[] = {va_arg(ap, double), 0,
        find_htag(flags, ai, "", 'g')};

    ai[0] += space(flags, (int) tab[0]);
    type_g(tab, format, ai, flags);
}
