/*
** EPITECH PROJECT, 2023
** my_str_to_word_array
** File description:
** Splits a string into words
*/

#include <stdlib.h>
#include "../../include/my.h"

int my_str_to_word_array4(int i, char const *str)
{
    for (; !my_str_isalpha(str[i]) && !my_str_isnum(str[i]) &&
    str[i] != '\0'; i += 1) {
    }
    return (i);
}

char **my_str_to_word_array3(int i, int *tab2, char const *str, char **tab)
{
    int y = tab2[0];
    int compteur2 = tab2[1];

    for (int x = 0; y <= i; y += 1) {
        if (my_str_isalpha(str[y]) || my_str_isnum(str[y])) {
            tab[compteur2][x] = str[y];
            x += 1;
        }
    }
    return (tab);
}

int my_str_to_word_array2(char const *str)
{
    int compteur = 0;

    for (int i = 0; str[i] != '\0'; i += 1) {
        if (!my_str_isalpha(str[i]) || !my_str_isnum(str[i]) ||
        str[i + 1] == '\0') {
            compteur += 1;
        }
    }
    return (compteur);
}

char **my_str_to_word_array(char const *str)
{
    int compteur = my_str_to_word_array2(str);
    char **tab = malloc(sizeof(char *) * (compteur + 1));
    int tab2[2];

    tab2[0] = 0;
    tab2[1] = 0;
    for (int i = 0; str[i] != '\0'; i += 1) {
        if (!my_str_isalpha(str[i]) || !my_str_isnum(str[i]) ||
        str[i + 1] == '\0') {
            tab[tab2[1]] = malloc(i + 1);
            tab = my_str_to_word_array3(i, tab2, str, tab);
            tab2[0] = my_str_to_word_array4(i, str);
            tab2[1] += 1;
        }
    }
    tab[compteur] = NULL;
    return (tab);
}
