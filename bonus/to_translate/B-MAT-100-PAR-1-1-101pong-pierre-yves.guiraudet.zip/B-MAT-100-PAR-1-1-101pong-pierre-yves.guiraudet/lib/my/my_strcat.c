/*
** EPITECH PROJECT, 2023
** my_strcat
** File description:
** Concatenates two strings
*/

char *my_strcat(char *dest, char const *src)
{
    int i;

    for (i = 0; dest[i] != '\0'; i += 1);
    for (int y = 0; src[y] != '\0'; y += 1)
        dest[i + y] = src[y];
    return (dest);
}
