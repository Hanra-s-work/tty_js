/*
** EPITECH PROJECT, 2023
** type_s_c_p_n.c
** File description:
** Functions with %s, %c, %%, %p, %n.
*/

#include <stdarg.h>
#include "../../include/my.h"
#include "../../include/functions.h"
#include "../../include/my_macro_abs.h"

void type_s(va_list ap, const char *format, int *ai, char *flags)
{
    char *c = va_arg(ap, char *);
    int width = find_width(format, ai);
    int prec = find_precision(format, ai);

    ai[0] += place_spaces(flags, width, my_strlen(c), 0);
    if (width == 0)
        width = my_strlen(c);
    if (prec == -1)
        prec = my_strlen(c);
    for (int i = 0; prec > i; i += 1) {
        my_putchar(c[i]);
        ai[0] += 1;
    }
    ai[0] += place_spaces(flags, width, my_strlen(c), 1);
}

void type_c(va_list ap, const char *format, int *ai, char *flags)
{
    char c = va_arg(ap, int);
    int width = find_width(format, ai);

    ai[0] += place_spaces(flags, width, 1, 0);
    my_putchar(c);
    ai[0] += 1;
    ai[0] += place_spaces(flags, width, 1, 1);
}

void type_pourcent(va_list ap, const char *format, int *ai, char *flags)
{
    my_putchar('%');
    ai[0] += 1;
}

void type_p(va_list ap, const char *format, int *ai, char *flags)
{
    void *p = va_arg(ap, void *);
    char *c = convert_base(&p, "0123456789", "0123456789abcdef");

    ai[0] += place_spaces(flags, find_width(format, ai), my_strlen(c) + 2, 0);
    my_putstr("0x");
    my_putstr(c);
    ai[0] += my_strlen(c) + 2;
    ai[0] += place_spaces(flags, find_width(format, ai), my_strlen(c) + 2, 1);
}

void type_n(va_list ap, const char *format, int *ai, char *flags)
{
    int *a = va_arg(ap, int *);

    *a = (int) ai[0];
}
