/*
** EPITECH PROJECT, 2023
** mini_printf
** File description:
** Display all we want
*/

#include <stdarg.h>
#include "my.h"

int type_printf2(const char *format, va_list ap, int *a)
{
    switch (format[0]) {
    case 'c':
        my_putchar(va_arg(ap, int));
        break;
    case '%':
        my_putchar(format[0]);
        break;
    default:
        return (-2147483648);
    }
    return (0);
}

int type_printf(const char *format, va_list ap, int *a, char *c)
{
    switch (format[0]) {
    case 'd':
    case 'i':
        a[0] = va_arg(ap, int);
        my_put_nbr(a[0]);
        for (; a[0] > 10; a[0] /= 10)
            a[1] += 1;
        a[0] = a[1];
        break;
    case 's':
        c = va_arg(ap, char *);
        my_putstr(c);
        a[0] = my_strlen(c) - 1;
        break;
    default:
        a[0] = type_printf2(format, ap, a);
    }
    return (a[0] + 1);
}

int mini_printf(const char *format, ...)
{
    va_list ap;
    int a = 0;
    int b[] = {
        0, 0
    };

    va_start(ap, format);
    for (int i = 0; i < my_strlen(format); i += 1) {
        if (format[i] == '%') {
            a += type_printf(&format[i + 1], ap, b, "");
            i += 1;
        } else {
            my_putchar(format[i]);
            a += 1;
        }
    }
    va_end(ap);
    return (a);
}
