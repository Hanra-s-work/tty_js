/*
** EPITECH PROJECT, 2023
** my_strncmp
** File description:
** Compare both strings until n caracter
*/

int my_strncmp(char const *s1, char const *s2, int n)
{
    int i;

    for (i = 0; s1[i] != '\0' && s2[i] != '\0' && i < n; i += 1) {
        if (s1[i] != s2[i]) {
            return ((int) s1[i] - (int) s2[i]);
        }
    }
    if (s1[i] != s2[i] && i < n) {
        return ((int) s1[i] - (int) s2[i]);
    }
    return (0);
}
