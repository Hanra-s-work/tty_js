/*
** EPITECH PROJECT, 2023
** my_strncat
** File description:
** Concatenates n characters of the two strings
*/

char *my_strncat(char *dest, char const *src, int nb)
{
    int i;

    for (i = 0; dest[i] != '\0'; i += 1);
    for (int y = 0; src[y] != '\0' && y < nb; y += 1) {
        dest[i + y] = src[y];
        if (y == nb - 1)
            dest[i + y + 1] = '\0';
    }
    return (dest);
}
