/*
** EPITECH PROJECT, 2023
** type_u_o_x.c
** File description:
** Functions with %u, %o, %x, %X.
*/

#include <stdarg.h>
#include "../../include/my.h"
#include "../../include/functions.h"
#include "../../include/my_macro_isnum.h"
#include "../../include/my_macro_abs.h"

void my_put_nbr_unsigned(unsigned nb, int *ai)
{
    if (nb >= 10) {
        my_put_nbr_unsigned(nb / 10, ai);
        my_put_nbr_unsigned(nb % 10, ai);
    } else if (nb < 0) {
        my_putchar('-');
        ai[0] += 1;
        return (my_put_nbr_unsigned(nb * -1, ai));
    } else {
        my_putchar(nb + 48);
        ai[0] += 1;
    }
}

void type_u(va_list ap, const char *format, int *ai, char *flags)
{
    unsigned int a = va_arg(ap, unsigned int);
    int prec = 0;
    int i = 1;
    int width = find_width(format, ai);

    if (a != 0 || find_precision(format, ai) != 0) {
        for (unsigned int a_bis = a; a_bis >= 10; a_bis /= 10) {
            i += 1;
        }
        for (int temp = find_precision(format, ai); temp > i; temp -= 1)
            prec += 1;
        ai[0] += place_spaces(flags, width, i + prec, 0);
        for (int temp = 0; temp < prec; temp += 1)
            my_putchar('0');
        my_put_nbr_unsigned(a, ai);
        ai[0] += place_spaces(flags, width, i + prec, 1);
        ai[0] += i + prec;
    }
}

void type_o(va_list ap, const char *format, int *ai, char *flags)
{
    char *c = my_putnbr_base(va_arg(ap, unsigned int), "01234567");
    int i = !find_htag(flags, ai, c, 'o');

    ai[0] += place_spaces(flags, find_width(format, ai), my_strlen(c) + i, 0);
    my_putstr(c);
    ai[0] += my_strlen(c);
    ai[0] += place_spaces(flags, find_width(format, ai), my_strlen(c) + i, 1);
}

void type_x(va_list ap, const char *format, int *ai, char *flags)
{
    char *c = my_putnbr_base(va_arg(ap, unsigned int), "0123456789abcdef");
    int	i = !find_htag(flags, ai, "", 'x') * 2;

    ai[0] += place_spaces(flags, find_width(format, ai), my_strlen(c) + i, 0);
    my_putstr(c);
    ai[0] += my_strlen(c);
    ai[0] += place_spaces(flags, find_width(format, ai), my_strlen(c) + i, 1);
}

void type_x_maj(va_list ap, const char *format, int *ai, char *flags)
{
    char *c = my_putnbr_base(va_arg(ap, unsigned int), "0123456789ABCDEF");
    int i = !find_htag(flags, ai, "", 'X') * 2;

    ai[0] += place_spaces(flags, find_width(format, ai), my_strlen(c) + i, 0);
    my_putstr(c);
    ai[0] += my_strlen(c);
    ai[0] += place_spaces(flags, find_width(format, ai), my_strlen(c) + i, 1);
}
