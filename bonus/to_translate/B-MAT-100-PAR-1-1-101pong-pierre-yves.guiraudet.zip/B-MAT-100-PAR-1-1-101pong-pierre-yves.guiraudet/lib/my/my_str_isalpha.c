/*
** EPITECH PROJECT, 2023
** my_str_isalpha
** File description:
** Returns 1 if the string passed as parameter only
** contains alphabetical characters
*/

int my_str_isalpha(char const *str)
{
    int bol = 1;

    for (int i = 0; str[i] != '\0'; i += 1) {
        if (str[i] < 65 || (str[i] > 90 && str[i] < 97) || str[i] > 122) {
            bol = 0;
        }
    }
    return (bol);
}
