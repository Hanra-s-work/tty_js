/*
** EPITECH PROJECT, 2023
** my_is_prime
** File description:
** Returns 1 if the number is prime and 0 if not
*/

int my_is_prime(int nb)
{
    int i;

    for (i = 2; (nb % i) > 0 && i <= nb; i += 1) {
    }
    if (i == nb) {
        return (1);
    } else {
        return (0);
    }
}
