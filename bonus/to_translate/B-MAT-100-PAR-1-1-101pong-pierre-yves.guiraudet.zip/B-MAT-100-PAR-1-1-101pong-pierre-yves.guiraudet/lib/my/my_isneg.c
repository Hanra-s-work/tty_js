/*
** EPITECH PROJECT, 2023
** my_isneg
** File description:
** say N if the number given to the function is negative, P if it is positive
*/

#include <unistd.h>

int my_isneg(int n)
{
    if (n < 0) {
        my_putchar('N');
    } else {
        my_putchar('P');
    }
    my_putchar('\n');
    return (0);
}
