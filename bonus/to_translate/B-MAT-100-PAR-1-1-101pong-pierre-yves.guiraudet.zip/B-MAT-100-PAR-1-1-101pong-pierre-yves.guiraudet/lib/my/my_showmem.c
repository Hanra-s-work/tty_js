/*
** EPITECH PROJECT, 2023
** my_showmem
** File description:
** Display a memory dump
*/

int my_showmem(char const *str, int size)
{
    return (0);
}
