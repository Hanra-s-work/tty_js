/*
** EPITECH PROJECT, 2023
** my_strcapitalize
** File description:
** Capitalizes the first letter of each word
*/

char *my_strcapitalize(char *str)
{
    if (str[0] > 96 && str[0] < 123) {
        str[0] -= 32;
    }
    for (int i = 1; str[i] != '\0'; i += 1) {
        if ((str[i - 1] < 65 || (str[i - 1] > 90 && str[i - 1] < 97) ||
        str[i - 1] > 122) && (str[i] > 97 && str[i] < 123)) {
            str[i] -= 32;
        }
    }
    return (str);
}
