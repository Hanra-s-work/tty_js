/*
** EPITECH PROJECT, 2023
** my_revstr
** File description:
** Reverses a string
*/

char *my_revstr(char *str)
{
    int compteur = 0;
    int i = 0;

    for (; str[compteur] != 0; compteur += 1) {
    }
    compteur -= 1;
    for (char a; i < (compteur + 1) / 2; i += 1) {
        a = str[i];
        str[i] = str[compteur - i];
        str[compteur - i] = a;
    }
    return (str);
}
