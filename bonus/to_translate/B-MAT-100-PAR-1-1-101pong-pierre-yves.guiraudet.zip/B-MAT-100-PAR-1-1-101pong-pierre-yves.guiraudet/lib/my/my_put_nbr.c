/*
** EPITECH PROJECT, 2023
** my_put_nbr
** File description:
** Display any number
*/

int my_put_nbr(int nb)
{
    if (nb >= 10) {
        my_put_nbr(nb / 10);
        my_put_nbr(nb % 10);
    } else if (nb < 0) {
        my_putchar('-');
        return (my_put_nbr(nb * -1));
    } else {
        my_putchar(nb + 48);
    }
}
