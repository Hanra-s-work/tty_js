/*
** EPITECH PROJECT, 2023
** my_compute_square_root
** File description:
** Returns the square root of the number given as argument
*/

int my_compute_square_root(int nb)
{
    if (nb < 1) {
        return (0);
    }
    for (int i = 1; (i * i) != nb || i <= nb; i += 1) {
        if (i * i == nb) {
            return (i);
        }
        if (i == nb) {
            return (0);
        }
    }
}
