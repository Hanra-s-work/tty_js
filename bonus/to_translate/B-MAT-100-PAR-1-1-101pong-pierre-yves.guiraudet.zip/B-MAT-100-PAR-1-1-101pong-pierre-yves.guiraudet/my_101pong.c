/*
** EPITECH PROJECT, 2023
** 101pong.c
** File description:
** Project 101 pong
*/

#include <math.h>
#include <stdio.h>
#include <stdlib.h>
#include "include/my.h"
#include "include/my_macro_abs.h"
#include "include/my_macro_isnum.h"

void find_angle(double *cd)
{
    double temp = 0;

    if ((cd[6] > 0 && cd[9] < 0) || (cd[6] < 0 && cd[9] > 0)
        || (cd[6] == 0 && cd[9] == 0)) {
        temp += atan(ABS(cd[9]) / sqrt((cd[7] * cd[7]) + (cd[8] * cd[8])));
        printf("The incidence angle is:\n%.2f degrees\n", temp * 180 / M_PI);
    } else {
        printf("The ball won't reach the paddle.\n");
    }
}

float getfloat(char *nb)
{
    double nbr = my_getnbr(nb);
    double dec;
    int i;

    for (i = 0; nb[i] != '.' && nb[i] != '\0'; i += 1);
    if (nb[i] == '.') {
        dec = my_getnbr(&nb[i + 1]);
        for (; dec >= 1; dec /= 10);
        for (; nb[i + 1] == '0'; i += 1)
            dec /= 10;
        if (nbr < 0)
            nbr -= dec;
        else
            nbr += dec;
    }
    return nbr;
}

void setup_coord(int ac, char **av)
{
    double coord[13];

    coord[0] = my_getnbr(av[7]);
    for (int i = 1; i < 7; i += 1)
        coord[i] = getfloat(av[i]);
    for (int i = 7; i < 10; i += 1)
        coord[i] = coord[i - 3]	- coord[i - 6];
    for (int i = 10; i < 13; i += 1)
        coord[i] = coord[i - 6];
    for (int temp = 0; temp < coord[0]; temp += 1)
        for (int i = 10; i < 13; i += 1)
            coord[i] += coord[i - 3];
    printf("The velocity vector of the ball is:\n(%.2f, %.2f, %.2f)\n",
        coord[7], coord[8], coord[9]);
    printf("At time t + %g, ball coordinates will be:\n(%.2f, %.2f, %.2f)\n",
        coord[0], coord[10], coord[11], coord[12]);
    find_angle(coord);
}

int test_errors_compute(int ac, char **av)
{
    char *temp;
    int a = 0;

    if (ac != 8)
        return 84;
    for (int i = 0; i < 6; i += 1)
        a += my_strlen(av[i + 1]);
    temp = malloc(sizeof(char) * a);
    if (my_getnbr(av[7]) < 0)
        return 84;
    for (int i = 0; i < my_strlen(av[7]); i += 1)
        if (!ISNUM(av[7][i]))
            return 84;
    for (int i = 0; i < 6; i += 1)
        my_strcat(temp, av[i + 1]);
    for (int i = 0; i < a; i += 1)
        if (!ISNUM(temp[i]) && temp[i] != '.' && temp[i] != '-')
            return 84;
    setup_coord(ac, av);
    return 0;
}

int main(int ac, char **av)
{
    if (ac == 2)
        if (av[1][0] == '-' && av[1][1] == 'h') {
            printf("USAGE\n    ./101pong x0 y0 z0 x1 y1 z1 n\n\n");
            printf("DESCRIPTION\n    x0  ball abscissa at time t - 1\n");
            printf("    y0  ball ordinate at time t - 1\n");
            printf("    z0  ball altitude at time t - 1\n");
            printf("    x1  ball abscissa at time t\n");
            printf("    y1  ball ordinate at time t\n");
            printf("    z1  ball altitude at time t\n    n");
            printf("   time shift (greater than or equal to zero, integer)\n");
        } else
            return 84;
    else
        return test_errors_compute(ac, av);
}
